"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check, User, Car } from "lucide-react"
import { useState } from "react"

const features = [
  "Have your own private driver/guide with extensive knowledge of the city",
  "Pick-up available (included in price)",
  "Can be booked for up to 8 per booking",
]

const pricingOptions = {
  chauffeur: [
    { duration: "Hourly", price: 30, period: "/hour" },
    { duration: "Daily", price: 250, period: "/day" },
    { duration: "Weekly", price: 1100, period: "/week" },
  ],
  driverCar: [
    { duration: "Hourly", price: 50, period: "/hour" },
    { duration: "Daily", price: 350, period: "/day" },
    { duration: "Weekly", price: 2500, period: "/week" },
  ],
}

export function Pricing() {
  const [selectedOption, setSelectedOption] = useState<"chauffeur" | "driverCar">("driverCar")

  return (
    <section id="pricing" className="py-16 sm:py-20 lg:py-32 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-8 sm:mb-12">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-foreground mb-3 sm:mb-4 text-balance">
            Transparent Pricing
          </h2>
          <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
            Choose the service that fits your needs
          </p>
        </div>

        <div className="max-w-md mx-auto mb-8">
          <div className="bg-foreground/5 p-1.5 rounded-full flex gap-1">
            <button
              onClick={() => setSelectedOption("chauffeur")}
              className={`flex-1 py-3 px-6 rounded-full text-sm sm:text-base font-semibold transition-all duration-300 ${
                selectedOption === "chauffeur"
                  ? "bg-foreground text-background shadow-lg"
                  : "text-foreground/60 hover:text-foreground"
              }`}
            >
              <User className="w-4 h-4 inline-block mr-2 -mt-0.5" />
              Chauffeur
            </button>
            <button
              onClick={() => setSelectedOption("driverCar")}
              className={`flex-1 py-3 px-6 rounded-full text-sm sm:text-base font-semibold transition-all duration-300 ${
                selectedOption === "driverCar"
                  ? "bg-foreground text-background shadow-lg"
                  : "text-foreground/60 hover:text-foreground"
              }`}
            >
              <Car className="w-4 h-4 inline-block mr-2 -mt-0.5" />
              Driver + Car
            </button>
          </div>
        </div>

        <div className="max-w-2xl mx-auto text-center mb-8 sm:mb-12">
          <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
            {selectedOption === "chauffeur" ? (
              <>
                <strong className="text-foreground">Chauffeur Service:</strong> Professional driver for your own
                vehicle. Perfect when you want to use your car but need an experienced driver.
              </>
            ) : (
              <>
                <strong className="text-foreground">Driver + Car Service:</strong> Complete transportation solution with
                a premium vehicle and professional driver. Ideal for those without a vehicle or seeking luxury
                transport.
              </>
            )}
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid sm:grid-cols-3 gap-4 sm:gap-6 mb-8 sm:mb-12">
            {pricingOptions[selectedOption].map((option, index) => (
              <Card
                key={index}
                className={`relative overflow-hidden bg-card border-2 transition-all duration-300 hover:shadow-2xl hover:scale-105 group ${
                  index === 1
                    ? "border-foreground shadow-xl sm:scale-105"
                    : "border-foreground/10 hover:border-foreground/30"
                }`}
              >
                {index === 1 && (
                  <div className="absolute top-0 left-0 right-0 bg-foreground text-background text-xs font-bold py-2 text-center">
                    MOST POPULAR
                  </div>
                )}
                <div className={`p-6 sm:p-8 ${index === 1 ? "pt-12" : ""}`}>
                  <div className="text-center mb-6">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                      {option.duration}
                    </h4>
                    <div className="flex items-baseline justify-center gap-1">
                      <span className="text-4xl sm:text-5xl font-bold text-foreground">€{option.price}</span>
                      <span className="text-lg text-muted-foreground">{option.period}</span>
                    </div>
                  </div>
                  <Button
                    className={`w-full py-6 text-base font-semibold transition-all duration-300 ${
                      index === 1
                        ? "bg-foreground text-background hover:bg-foreground/90 shadow-lg"
                        : "bg-foreground/5 text-foreground hover:bg-foreground hover:text-background"
                    }`}
                  >
                    Book Now
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          <Card className="p-6 sm:p-8 bg-card border-2 border-foreground/10">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-10 h-10 rounded-full bg-foreground flex items-center justify-center flex-shrink-0">
                <Check className="w-5 h-5 text-background" />
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-foreground mb-2">What's Included</h3>
                <p className="text-sm text-muted-foreground">All bookings come with these benefits</p>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-foreground/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Check className="w-3 h-3 text-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{feature}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
