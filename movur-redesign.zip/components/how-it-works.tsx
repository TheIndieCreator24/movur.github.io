import { Card } from "@/components/ui/card"
import { Wrench, Briefcase, Plane, PartyPopper, ClipboardCheck, Users } from "lucide-react"
import Image from "next/image"

const steps = [
  {
    number: "01",
    title: "Select Your Service",
    description: "Choose between a Personal Chauffeur or Car Movement (book by the minute, hour, day, week, or month).",
  },
  {
    number: "02",
    title: "Set Your Trip Details",
    description:
      "Add your pickup and drop-off locations or simply use your saved places like Home or Work for quick booking.",
  },
  {
    number: "03",
    title: "Chauffeur Assigned & Ready",
    description:
      "A Movur is matched to your request and will arrive at your location within 10 minutes. Your car, comfort and control made effortless.",
  },
]

const benefits = [
  {
    icon: Wrench,
    title: "Dropping car for service",
    description:
      "We will drop your car at your favorite garage and return back when the job is done. Avoid work time disruption. Save time for better things in life.",
    image: "/car-service-garage-mechanic.jpg",
  },
  {
    icon: Briefcase,
    title: "Stay Cool for Business Meetings",
    description:
      "Work on that last minute presentation without pressure while we take you around for your meetings across the city. No more rushing for parking or waiting for cabs.",
    image: "/business-professional-working-in-car.jpg",
  },
  {
    icon: Plane,
    title: "Pick/drop from airport",
    description:
      "Worried about that extra child seat or trunk space. You know your car better. Simply schedule a Movur to get to and from the airport without any difficulty.",
    image: "/car-airport-luggage-travel.jpg",
  },
  {
    icon: PartyPopper,
    title: "Driving you home safely after a party",
    description:
      "Be least worried about leaving your car overnight or booking two-way expensive cabs. We'll make sure you're out and back home safely.",
    image: "/safe-night-driving-party.jpg",
  },
  {
    icon: ClipboardCheck,
    title: "Vehicle inspection",
    description:
      "Get the inspection done from the comfort of your own home. Save your precious time. We will take your car to the nearest inspection center and get your inspection certificate.",
    image: "/car-inspection-certificate.jpg",
  },
  {
    icon: Users,
    title: "Take your loved ones around",
    description:
      "Family outings or outstation trips. We will drive your loved ones in the comfort of your own car. Convenience at its best.",
    image: "/family-road-trip-car.jpg",
  },
]

export function HowItWorks() {
  return (
    <section id="how" className="py-16 sm:py-20 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-bold tracking-tight text-foreground mb-3 sm:mb-4">
            How It Works
          </h2>
          <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
            Three simple steps to premium transportation
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {steps.map((step, index) => (
            <Card
              key={index}
              className="p-6 sm:p-6 lg:p-8 hover:shadow-lg transition-all duration-300 border-2 hover:border-foreground/20 bg-card"
            >
              <div className="text-4xl sm:text-5xl font-bold text-muted-foreground/20 mb-4">{step.number}</div>
              <h3 className="text-lg sm:text-xl font-bold mb-3 text-foreground">{step.title}</h3>
              <p className="text-muted-foreground leading-relaxed text-sm sm:text-base">{step.description}</p>
            </Card>
          ))}
        </div>

        <div className="mt-20 sm:mt-24 lg:mt-32">
          <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl lg:text-5xl font-bold tracking-tight text-foreground mb-3 sm:mb-4">
              Helping you with...
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon
              return (
                <Card
                  key={index}
                  className="group overflow-hidden hover:shadow-xl transition-all duration-300 border-2 hover:border-foreground/20 bg-card"
                >
                  <div className="relative h-48 sm:h-56 overflow-hidden">
                    <Image
                      src={benefit.image || "/placeholder.svg"}
                      alt={benefit.title}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/90 flex items-center justify-center mb-3">
                        <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-foreground" />
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-white">{benefit.title}</h3>
                    </div>
                  </div>
                  <div className="p-5 sm:p-6">
                    <p className="text-muted-foreground leading-relaxed text-sm sm:text-base">{benefit.description}</p>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
