import { Users, MapPin, Wrench } from "lucide-react"

const stats = [
  {
    icon: Users,
    value: "1,700+",
    label: "Clients Transported",
  },
  {
    icon: MapPin,
    value: "150K",
    label: "Miles Driven This Year",
  },
  {
    icon: Wrench,
    value: "4,500+",
    label: "Services Performed",
  },
]

export function SocialProof() {
  return (
    <section className="py-12 sm:py-16 lg:py-20 border-y border-border/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 sm:gap-6 max-w-5xl mx-auto">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <div key={index} className="flex flex-col items-center text-center group">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-foreground/5 flex items-center justify-center mb-4 group-hover:bg-foreground/10 transition-colors duration-300">
                  <Icon className="w-7 h-7 sm:w-8 sm:h-8 text-foreground" />
                </div>
                <div className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-2">{stat.value}</div>
                <div className="text-sm sm:text-base text-muted-foreground font-medium">{stat.label}</div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
