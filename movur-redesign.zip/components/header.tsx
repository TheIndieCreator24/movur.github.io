"use client"

import { useState } from "react"
import { Menu, X, Globe } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [language, setLanguage] = useState("EN")

  const handleLanguageChange = (lang: string) => {
    setLanguage(lang)
    if (lang === "PT") {
      // Redirect to Portuguese version
      window.location.href = "/pt"
    } else {
      // Redirect to English version
      window.location.href = "/"
    }
  }

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-accent/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <div className="flex-shrink-0">
              <h1 className="text-2xl lg:text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Movur
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <a
                href="#services"
                className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              >
                Services
              </a>
              <a href="#how" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
                How It Works
              </a>
              <a
                href="#pricing"
                className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              >
                Pricing
              </a>
              <a href="#faq" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
                FAQs
              </a>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="gap-2">
                    <Globe className="h-4 w-4" />
                    {language}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => handleLanguageChange("EN")}>English</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleLanguageChange("PT")}>Portuguese</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button size="lg" className="ml-4">
                Book Now
              </Button>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 text-primary"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </header>

      {isMenuOpen && (
        <div className="fixed inset-0 z-[60] md:hidden bg-background">
          {/* Close button */}
          <div className="absolute top-4 right-4">
            <button onClick={() => setIsMenuOpen(false)} className="p-2 text-primary" aria-label="Close menu">
              <X className="h-6 w-6" />
            </button>
          </div>

          {/* Menu content */}
          <div className="flex flex-col items-center justify-center h-full gap-8 px-4">
            <a
              href="#services"
              className="text-2xl font-medium text-foreground hover:text-primary transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Services
            </a>
            <a
              href="#how"
              className="text-2xl font-medium text-foreground hover:text-primary transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              How It Works
            </a>
            <a
              href="#pricing"
              className="text-2xl font-medium text-foreground hover:text-primary transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Pricing
            </a>
            <a
              href="#faq"
              className="text-2xl font-medium text-foreground hover:text-primary transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              FAQs
            </a>

            <div className="flex gap-4 mt-4">
              <Button variant={language === "EN" ? "default" : "outline"} onClick={() => handleLanguageChange("EN")}>
                English
              </Button>
              <Button variant={language === "PT" ? "default" : "outline"} onClick={() => handleLanguageChange("PT")}>
                Portuguese
              </Button>
            </div>

            <Button size="lg" className="w-64 mt-4" onClick={() => setIsMenuOpen(false)}>
              Book Now
            </Button>
          </div>
        </div>
      )}
    </>
  )
}
