import { Button } from "@/components/ui/button"
import { Clock, MapPin } from "lucide-react"

export function Services() {
  return (
    <section id="services" className="py-12 sm:py-16 lg:py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-8 sm:mb-12 lg:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-6xl font-bold tracking-tight text-foreground mb-3 sm:mb-4">
            Choose Your Service
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-muted-foreground leading-relaxed">
            Select the perfect option for your journey
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-4 sm:gap-6 max-w-7xl mx-auto">
          {/* Book a Chauffeur Card */}
          <div className="group relative overflow-hidden rounded-3xl bg-card border-2 border-border hover:border-foreground transition-all duration-500 hover:shadow-2xl">
            <div className="relative h-64 sm:h-80 lg:h-96 overflow-hidden">
              <img
                src="/professional-chauffeur-standing-next-to-luxury-car.jpg"
                alt="Professional Chauffeur"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/95 via-foreground/60 to-transparent" />

              <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8 lg:p-10">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 sm:px-4 sm:py-2 bg-background/90 backdrop-blur-sm rounded-full mb-4">
                  <Clock className="h-3 w-3 sm:h-4 sm:w-4 text-foreground flex-shrink-0" />
                  <span className="text-[11px] sm:text-sm font-medium text-foreground whitespace-nowrap">
                    Flexible Duration
                  </span>
                </div>

                <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-background mb-3 sm:mb-4">
                  Book a Chauffeur
                </h3>
                <p className="text-background/90 text-base sm:text-lg leading-relaxed mb-6 max-w-md">
                  Get a dedicated professional driver for your own car. Available hourly, daily, weekly, or yearly.
                </p>

                <Button
                  size="lg"
                  className="w-full sm:w-auto text-base sm:text-lg px-8 py-6 bg-background text-foreground hover:bg-background/90 transition-all duration-300 group-hover:scale-105"
                >
                  Book Chauffeur Now
                </Button>
              </div>
            </div>
          </div>

          {/* Private Driver + Car Card */}
          <div className="group relative overflow-hidden rounded-3xl bg-card border-2 border-border hover:border-foreground transition-all duration-500 hover:shadow-2xl">
            <div className="relative h-64 sm:h-80 lg:h-96 overflow-hidden">
              <img
                src="/luxury-black-sedan-car-interior-with-leather-seats.jpg"
                alt="Luxury Car Service"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/95 via-foreground/60 to-transparent" />

              <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8 lg:p-10">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 sm:px-4 sm:py-2 bg-background/90 backdrop-blur-sm rounded-full mb-4">
                  <MapPin className="h-3 w-3 sm:h-4 sm:w-4 text-foreground flex-shrink-0" />
                  <span className="text-[11px] sm:text-sm font-medium text-foreground whitespace-nowrap">
                    Complete Package
                  </span>
                </div>

                <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-background mb-3 sm:mb-4">
                  Driver + Car
                </h3>
                <p className="text-background/90 text-base sm:text-lg leading-relaxed mb-6 max-w-md">
                  Enjoy a premium ride with both professional driver and luxury car service on your schedule.
                </p>

                <Button
                  size="lg"
                  className="w-full sm:w-auto text-base sm:text-lg px-8 py-6 bg-background text-foreground hover:bg-background/90 transition-all duration-300 group-hover:scale-105"
                >
                  Book Driver + Car
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
