import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Crown, Shield, Clock, Star } from "lucide-react"

const features = [
  {
    icon: Crown,
    title: "VIP Treatment",
    description: "Exclusive access to our premium fleet and top-rated drivers",
  },
  {
    icon: Shield,
    title: "Priority Service",
    description: "Guaranteed availability with dedicated driver assignment",
  },
  {
    icon: Clock,
    title: "24/7 Availability",
    description: "Round-the-clock service for all your transportation needs",
  },
  {
    icon: Star,
    title: "Personalized Experience",
    description: "Tailored service that reflects your status and preferences",
  },
]

export function MovurBlack() {
  return (
    <section className="py-16 sm:py-20 lg:py-32 bg-foreground text-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 sm:mb-16">
            <div className="inline-block px-4 py-2 bg-background/10 rounded-full mb-4">
              <p className="text-sm sm:text-base font-medium text-background/90">Looking for monthly driver?</p>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-6xl font-bold tracking-tight text-background mb-4 sm:mb-6">
              Discover Movur Black
            </h2>
            <p className="text-lg sm:text-xl text-background/80 leading-relaxed max-w-3xl mx-auto">
              The epitome of luxury, personalized around you and your family. A monthly subscription service that
              reflects your status, image, and reputation.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <Card
                  key={index}
                  className="p-6 bg-background/5 border-background/20 hover:bg-background/10 transition-all duration-300 backdrop-blur-sm"
                >
                  <div className="w-12 h-12 rounded-full bg-background/10 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-background" />
                  </div>
                  <h3 className="text-lg font-bold text-background mb-2">{feature.title}</h3>
                  <p className="text-sm text-background/70 leading-relaxed">{feature.description}</p>
                </Card>
              )
            })}
          </div>

          <div className="text-center">
            <Button
              size="lg"
              className="bg-background text-foreground hover:bg-background/90 text-base sm:text-lg px-8 sm:px-12 py-6 sm:py-7"
            >
              Learn More About Movur Black
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
