import { Card } from "@/components/ui/card"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Sarah Mitchell",
    service: "Airport Transfer",
    rating: 5,
    text: "Absolutely fantastic service! My driver was punctual, professional, and made my airport transfer stress-free. The car was immaculate and the ride was smooth. Will definitely use Movur again!",
    date: "2 weeks ago",
  },
  {
    name: "James Rodriguez",
    service: "Business Meetings",
    rating: 5,
    text: "I booked Movur for a full day of business meetings across the city. The driver was incredibly professional and knew all the best routes. I was able to work in the car without any distractions. Highly recommend!",
    date: "1 month ago",
  },
  {
    name: "Emma Thompson",
    service: "Car Service Drop-off",
    rating: 5,
    text: "What a time-saver! They picked up my car, took it for service, and returned it the same day. I didn't have to miss any work. The convenience is unmatched. Thank you Movur!",
    date: "3 weeks ago",
  },
  {
    name: "Michael Chen",
    service: "Family Road Trip",
    rating: 5,
    text: "We hired Movur for a weekend family trip. The driver was wonderful with our kids and made the journey enjoyable. Having our own car with a professional driver was the perfect solution. Five stars!",
    date: "1 week ago",
  },
  {
    name: "Lisa Anderson",
    service: "Evening Event",
    rating: 5,
    text: "Used Movur for a company event and it was perfect. No worries about parking or having a designated driver. The service was seamless from booking to drop-off. Will use for all future events!",
    date: "2 months ago",
  },
  {
    name: "David Park",
    service: "Vehicle Inspection",
    rating: 5,
    text: "Brilliant service! They handled my vehicle inspection while I worked from home. Saved me hours of waiting at the inspection center. The driver was courteous and kept me updated throughout. Excellent!",
    date: "3 weeks ago",
  },
]

export function Testimonials() {
  return (
    <section className="py-16 sm:py-20 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-bold tracking-tight text-foreground mb-3 sm:mb-4">
            What Our Clients Say
          </h2>
          <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
            Real experiences from real customers
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="p-6 hover:shadow-lg transition-all duration-300 border-2 hover:border-foreground/20 bg-card"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-foreground text-foreground" />
                ))}
              </div>
              <p className="text-sm sm:text-base text-muted-foreground leading-relaxed mb-6 italic">
                "{testimonial.text}"
              </p>
              <div className="border-t border-border/50 pt-4">
                <p className="font-bold text-foreground text-sm sm:text-base">{testimonial.name}</p>
                <p className="text-xs sm:text-sm text-muted-foreground">{testimonial.service}</p>
                <p className="text-xs text-muted-foreground/70 mt-1">{testimonial.date}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
