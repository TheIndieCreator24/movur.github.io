export function About() {
  return (
    <section id="about" className="py-20 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-foreground mb-6">
            About Movur
          </h2>
          <p className="text-lg lg:text-xl text-muted-foreground leading-relaxed max-w-3xl mx-auto">
            Movur brings effortless mobility to your lifestyle. Whether you need a chauffeur for your own car or a
            private driver with a car, our platform ensures reliability, professionalism, and comfort — every time you
            ride.
          </p>
        </div>
      </div>
    </section>
  )
}
