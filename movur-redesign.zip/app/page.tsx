import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { SocialProof } from "@/components/social-proof"
import { Services } from "@/components/services"
import { HowItWorks } from "@/components/how-it-works"
import { Pricing } from "@/components/pricing"
import { Testimonials } from "@/components/testimonials"
import { MovurBlack } from "@/components/movur-black"
import { FAQ } from "@/components/faq"
import { About } from "@/components/about"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <SocialProof />
      <Services />
      <HowItWorks />
      <Pricing />
      <Testimonials />
      <MovurBlack />
      <FAQ />
      <About />
      <Footer />
    </main>
  )
}
